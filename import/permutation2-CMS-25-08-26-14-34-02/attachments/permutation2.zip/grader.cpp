#include <cstdlib>
#include <iostream>
using namespace std;
// Functions to be implemented in the solution.
void bob_init(int n);
int query_from_alice(int a);
// Functions to be implemented in the solution.
namespace{
    int N, K, Query_count = 0, P[1005], Ans[1005], Inv[1005][1005];
    bool EndInit = false;
    void WA(const string msg) {
        cout << "Wrong Answer: " << msg << endl;
        exit(0);
    }
} int compare_numbers(int l, int r){
    if(EndInit)  WA("Invalid call");
    if(l <= 0 || l > N || r <= 0 || r > N || l > r)
        WA("Invalid position: " + to_string(l) + " " + to_string(r));
    Query_count++;
    return Inv[l][r];
} int main() {
	cin >> N >> K;
    for(int i = 1; i <= N; ++i) cin >> P[i];
	for(int i = 1; i <= N; ++i) for(int j = i + 1; j <= N; ++j)
		if(P[i] > P[j]) Inv[i][j]++;
	for(int i = 1; i <= N; ++i) for(int j = 1; j <= N; ++j) 
        Inv[i][j] += Inv[i][j - 1];
	for(int j = 1; j <= N; ++j) for(int i = j - 1; i > 0; --i) 
        Inv[i][j] += Inv[i + 1][j];
    bob_init(N);
    EndInit = true;
	for(int i = 1, x; i <= K; ++i)
		cin >> x, Ans[i] = query_from_alice(x);
    for(int i = 1; i <= K; ++i) cout << Ans[i] << " \n"[i == K];
	cout << Query_count / N << "\n";
}